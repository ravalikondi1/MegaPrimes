﻿using System;
using MegaPrimes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestMegaPrimes
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestPrimeNumber_WhenNumberGreaterThanZero()
        {
            int num = 37;
            Assert.IsTrue(Utility.IsPrime(num));
        }

        [TestMethod]
        public void TestPrimeNumber_WhenNumberLessThanZero()
        {
            int num = -7;
            Assert.IsFalse(Utility.IsPrime(num));
        }

        [TestMethod]
        public void TestMegaPrime_WhenNumberGreaterThanZero()
        {
            int num = 37;
            Assert.IsTrue(Utility.IsMegaPrime(num));
        }

        [TestMethod]
        public void TestMegaPrime_WhenNumberLessThanZero()
        {
            int num = -7;
            Assert.IsFalse(Utility.IsMegaPrime(num));
        }

        [TestMethod]
        public void TestMegaPrime_WhenPrimeNumer()
        {
            int num = 35;
            Assert.IsFalse(Utility.IsMegaPrime(num));
        }

        [TestMethod]
        public void TestMegaPrimeRange_WhenNumberGreaterThanZero()
        {
            int num = 37;
            Assert.AreEqual("[2,3,5,7,23,37]", Utility.GetAllMegaPrimes(num));
        }

        [TestMethod]
        public void TestMegaPrimeRange_WhenLargeNumber()
        {
            int num = 145;
            Assert.AreEqual("[2,3,5,7,23,37,53,73]", Utility.GetAllMegaPrimes(num));
        }

        [TestMethod]
        public void TestMegaPrimeRange_WhenNumberIsOne()
        {
            Assert.AreEqual("[]", Utility.GetAllMegaPrimes(1));
        }
    }
}
