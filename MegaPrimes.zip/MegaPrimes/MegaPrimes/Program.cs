﻿using System;

namespace MegaPrimes
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter maximum number to find MegaPrimes within the range");
            string max = Console.ReadLine();
            if (!string.IsNullOrEmpty(max))
            {
                int maxNum = Convert.ToInt32(max);
                if (maxNum > 0)
                {
                    Console.WriteLine("MegaPrime numbers b/w 1 & " + max + " :");
                    Console.WriteLine(Utility.GetAllMegaPrimes(maxNum));
                }
                else
                    Console.WriteLine("Number should be greater than 0");
            }
        }
    }
}

