﻿using System;
using System.Text;

namespace MegaPrimes
{
    public static class Utility
    {
        // to get all megaprimes within range
        public static string GetAllMegaPrimes(int maxNum)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                for (int num = 1; num <= maxNum; num++)
                {
                    if (num == 1)
                        sb.Append("[");

                    if (IsMegaPrime(num))
                        sb.Append(num + ",");

                    if (num == maxNum)
                    {
                        if (sb.Length > 1) sb.Remove(sb.Length - 1, 1);
                        sb.Append("]");
                    }
                }
                return sb.ToString();
            }
            catch(Exception ex)
            {
                //log error
                return string.Empty;
            }
        }

        // to check if number is mega prime
        public static bool IsMegaPrime(int number)
        {
            return CheckAllDigits(number) && IsPrime(number);
        }

        // to check digits all digits are prime or not
        public static bool CheckAllDigits(int number)
        {
            while (number > 0)
            {
                int digit = number % 10;
                if (digit != 2 && digit != 3 &&
                    digit != 5 && digit != 7)
                    return false;

                number /= 10;
            }
            return true;
        }

        // to check if number is prime or not
        public static bool IsPrime(int number)
        {
            if (number <= 1)
                return false;

            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0)
                    return false;
            }
            return true;
        }
    }
}
